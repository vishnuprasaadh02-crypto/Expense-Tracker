import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'

// GitHub Pages serves a project site under /<repo-name>/, so asset URLs
// need that prefix in production builds. Locally (vite dev) it's ignored.
export default defineConfig({
  plugins: [react()],
  base: process.env.GITHUB_PAGES === 'true' ? '/Expense-Tracker/' : '/',
  server: { port: 5173 },
})
